import json


def read_json(file):
     #obtengo objetos de archivo json y lo devuelve como lista
     with open(file, "r") as archivo:
        file_read = json.load(archivo)
     return file_read

def write_json(file,new_input):
    #escribe en archivo json
    with open(file, "w") as archivo:
        json.dump(new_input,archivo,indent=4)


def check_existence(list, find_key, find_value):
    found = 0

    for item in list :
        if item.get(find_key).upper() == find_value.upper():
            found = 1
            break
    return found



