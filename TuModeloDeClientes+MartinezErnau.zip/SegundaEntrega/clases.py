#Clase Persona

from SegundaEntrega.funciones import *

class Persona:
    def __init__ (self, nombre, apellido, direccion, telefono, DNI):
        self.nombre = nombre
        self.apellido = apellido
        self.direccion = direccion
        self.telefono = telefono
        self.DNI = DNI

#Clase Persona

class Cliente(Persona):
    def __init__ (self, nombre=None, apellido=None, direccion=None, telefono=None, DNI=None):
        super().__init__(nombre, apellido, direccion, telefono, DNI)
        self.__productos_comprados = []
        self.__file_clientes = "SegundaEntrega/clientes.json"
        #self.add_cliente()
        
    def comprar(self, producto):
        self.__productos_comprados.append(producto)

    def devolver_producto(self, producto):
        self.__productos_comprados.remove(producto)

    def get_productos_comprados(self):
        return self.__productos_comprados      

    def get_clientes(self):
        clientes = read_json(self.__file_clientes)
        return clientes
    
    def login(self):
        clientes = self.get_clientes()
        return check_existence(clientes, "DNI" ,self.DNI)
        
    def add_cliente(self):
         #obtiene los clientes del archivo
         clientes = self.get_clientes()

         #Chequea que el cliente no exista
         if check_existence(clientes, "DNI" ,self.DNI) == 0:

            dict_cliente = {"nombre" : self.nombre,
                            "apellido" : self.apellido,
                            "direccion" : self.direccion,
                            "telefono" : self.telefono,
                            "DNI" : self.DNI
                            }

            #agrega el nuevo cliente a la lista
            clientes.append(dict_cliente)
            #agrega cliente al archivo
            write_json(self.__file_clientes,clientes)
         else:
            print()
            print("EL CLIENTE YA EXISTE.") 

#Clase Producto

class Producto():

    def __init__(self, nombre=None, cantidad=None):
         self.__dict = {"nombre" : nombre, "stock" : cantidad}
         self.file_productos = "SegundaEntrega/productos.json"
         
    def get_product(self):
         productos = read_json(self.file_productos)
         return productos
           
    def comprar(self):
         #obtiene los productos del archivo
         productos = self.get_product()
         #Chequea que el producto exista

         if check_existence(productos, "nombre", self.__dict["nombre"]) == 1:
            
            for producto in productos:

                if producto.get("nombre").upper() == self.__dict["nombre"].upper() and producto.get("stock") > 0:
                    stk = producto.get("stock")
                    producto["stock"] = stk - 1

                    #agrega producto al archivo
                    write_json(self.file_productos,productos)
                    return 1
         else:
            return 0
         
    def devolver(self):
         #obtiene los productos del archivo
         productos = self.get_product()

         #Chequea que el producto exista
         if check_existence(productos, "nombre", self.__dict["nombre"]) == 1:
            
            for producto in productos:

                if producto.get("nombre").upper() == self.__dict["nombre"].upper():
                    stk = producto.get("stock")
                    producto["stock"] = stk + 1

                    #agrega producto al archivo
                    write_json(self.file_productos,productos)
                    return 1
         else:
            return 0