"""

"""
from SegundaEntrega.clases import *

print()
print("BIENVENIDO AL MODULO DE CLIENTES.")
print()

while True:
    
    print()
    print("0. Finalizar programa.")
    print("1. Crear Cliente.")
    print("2. Login.")
    print()
     
    opcion = input("Ingrese número de opción a realizar: ")

    if opcion == '0':
        break

    elif opcion == '1':
            DNI = input("Ingrese DNI cliente: ")
            
            if DNI == '':
                print("El DNI no puede ser vacío.")
                break
            else:
                nombre = input("Ingrese nombre cliente: ")
                apellido = input("Ingrese apellido cliente: ")
                direccion = input("Ingrese dirección cliente: ")
                telefono  = input("Ingrese teléfono cliente: ")

                cliente = Cliente(nombre, apellido, direccion, telefono, DNI)
                cliente.add_cliente()

    elif opcion == '2':
        cliente_dni = input("Ingrese DNI de cliente: ")
        cliente = Cliente(DNI=cliente_dni)
        
        if cliente.login() == 0: # no existe el cliente
            print()
            print("EL CLIENTE INGRESADO NO EXISTE.")
            continue

        print()
        print("CLIENTE LOGUEADO CORRECTAMENTE.")
        print()

    else:
        print()
        print("OPCION INCORRECTA.")
        continue


    while True:

        print()
        print("0. Volver al menú anterior.")
        print("1. Listar productos disponibles para comprar.")
        print("2. Comprar producto.")
        print("3. Devolver producto.")
        print("4. Ver productos comprados.")
        print()
        opcion = input("Ingrese número de opción a realizar: ")

        if opcion == '0':
            break

        elif opcion == '1':
            productos = read_json("SegundaEntrega/productos.json") 
            #print(productos)
            print()
            for producto in productos:
                print("-", producto.get("nombre"))

        elif opcion == '2':
            print()
            producto_nombre = input("Ingrese nombre producto a comprar: ")
            producto = Producto(nombre=producto_nombre)

            compra = producto.comprar()

            if compra == 1:
                cliente.comprar(producto_nombre)
                print()
                print("COMPRA REALIZADA CON EXITO.")
            else:
                print()
                print("EL PRODUCTO NO EXISTE O NO HAY STOCK DISPONIBLE")

            
        elif opcion == '3':
            print()
            producto_nombre = input("Ingrese nombre producto a devolver: ")
            producto = Producto(nombre=producto_nombre)

            devolucion = producto.devolver()

            if devolucion == 1:
                cliente.devolver_producto(producto_nombre)
                print()
                print("PRODUCTO DEVUELTO CORRECTAMENTE.")
            else:
                print()
                print("EL PRODUCTO NO EXISTE.")

        elif opcion == '4':
            for producto in cliente.get_productos_comprados():
                print("-", producto)
            


            


            
